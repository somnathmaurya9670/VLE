from django.db import models
from django.contrib.auth import get_user_model
from decimal import Decimal
from django.utils import timezone

User = get_user_model()

class BillCategory(models.Model):
    name = models.CharField(max_length=100)
    description = models.TextField()
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.name

class BillProvider(models.Model):
    name = models.CharField(max_length=100)
    category = models.ForeignKey(BillCategory, on_delete=models.CASCADE, related_name='providers')
    logo = models.ImageField(upload_to='bill_providers/', null=True, blank=True)
    api_endpoint = models.URLField()
    api_key = models.CharField(max_length=255)
    is_active = models.BooleanField(default=True)
    commission_rate = models.DecimalField(max_digits=5, decimal_places=2, default=0)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.name

class BillPayment(models.Model):
    STATUS_CHOICES = [
        ('pending', 'Pending'),
        ('success', 'Success'),
        ('failed', 'Failed'),
        ('refunded', 'Refunded')
    ]

    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='bill_payments')
    provider = models.ForeignKey(BillProvider, on_delete=models.CASCADE)
    bill_number = models.CharField(max_length=100)
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    commission = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending')
    transaction_id = models.CharField(max_length=100, unique=True)
    payment_details = models.JSONField(default=dict)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return f"{self.user.username} - {self.provider.name} - {self.amount}"

class Ledger(models.Model):
    name = models.CharField(max_length=15, null=True, blank=True)
    account_no = models.CharField(max_length=15, null=True, blank=True)
    customer_name = models.CharField(max_length=15, null=True, blank=True)
    amount = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    commission = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    mobile = models.CharField(max_length=15, null=True, blank=True)
    type = models.CharField(max_length=10, null=True, blank=True)
    category = models.CharField(max_length=10, null=True, blank=True)
    balance = models.DecimalField(max_digits=10, decimal_places=2)
    connect = models.ForeignKey('Passbook', null=True, blank=True, on_delete=models.SET_NULL)
    created_at = models.DateTimeField(auto_now_add=True)
    bill_payment = models.ForeignKey(BillPayment, null=True, blank=True, on_delete=models.SET_NULL)

class Passbook(models.Model):
    bnk_name = [
        ('kvb1', 'KVB'),
        ('hdfc', 'HDFC'),
        ('icici', 'ICICI')
    ]
    transtype = [
        ('deposit', 'deposit'),
        ('withdraw', 'withdraw')
    ]

    bank_name = models.CharField(max_length=15, choices=bnk_name)
    transcation_type = models.CharField(max_length=10, choices=transtype)
    purpose = models.CharField(max_length=15)
    deposit = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    withdraw = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    balance = models.DecimalField(max_digits=10, decimal_places=2)
    created_at = models.DateTimeField(auto_now_add=True)
    
    def save(self, *args, **kwargs):
        if self.transcation_type == 'deposit' and self.deposit:
            last_record = Passbook.objects.filter(bank_name=self.bank_name).order_by('-id').first()
            if last_record:
                self.balance = last_record.balance + self.deposit
            else:
                self.balance = self.deposit
        else:
            last_record = Passbook.objects.filter(bank_name=self.bank_name).order_by('-id').first()
            if last_record:
                bal = last_record.balance - self.withdraw
                if bal < 0:
                    raise ValueError("Balance is insufficient. Please top up.")
                self.balance = bal
            else:
                raise ValueError("No previous records found for this bank. Cannot perform withdrawal.")
        super().save(*args, **kwargs)

class Service(models.Model):
    name = models.CharField(max_length=100)
    description = models.TextField()
    price = models.DecimalField(max_digits=10, decimal_places=2)
    is_active = models.BooleanField(default=True)
    created_by = models.ForeignKey(User, on_delete=models.CASCADE, related_name='services_created', null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    category = models.ForeignKey(BillCategory, on_delete=models.SET_NULL, null=True, blank=True)
    provider = models.ForeignKey(BillProvider, on_delete=models.SET_NULL, null=True, blank=True)

    def __str__(self):
        return self.name

class PANCardApplication(models.Model):
    STATUS_CHOICES = [
        ('pending', 'Pending'),
        ('processing', 'Processing'),
        ('completed', 'Completed'),
        ('rejected', 'Rejected')
    ]

    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='pan_applications')
    application_number = models.CharField(max_length=20, unique=True)
    full_name = models.CharField(max_length=100)
    father_name = models.CharField(max_length=100)
    gender = models.CharField(max_length=20)
    dob = models.DateField()
    address = models.TextField()
    mobile = models.CharField(max_length=10)
    email = models.EmailField()
    aadhar = models.CharField(max_length=12)
    photo = models.ImageField(upload_to='pan_photos/')
    aadhar_copy = models.FileField(upload_to='pan_documents/')
    source = models.CharField(max_length=20)  # CSC or Website
    pan_type = models.CharField(max_length=20)  # UTI or NSDL
    bank_name = models.CharField(max_length=20, null=True, blank=True)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending')
    amount = models.DecimalField(max_digits=10, decimal_places=2, default=107)
    commission = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.full_name} - {self.application_number}"

    def save(self, *args, **kwargs):
        if not self.application_number:
            # Generate application number
            prefix = 'PAN'
            timestamp = timezone.now().strftime('%Y%m%d%H%M%S')
            self.application_number = f"{prefix}{timestamp}"
        
        # Calculate commission based on PAN type
        if self.pan_type == 'uti':
            self.commission = Decimal('9.63')
        else:
            self.commission = Decimal('9.37')
            
        super().save(*args, **kwargs)

class InsuranceApplication(models.Model):
    INSURANCE_TYPES = [
        ('life', 'Life Insurance'),
        ('health', 'Health Insurance'),
        ('motor', 'Motor Insurance'),
        ('home', 'Home Insurance'),
        ('travel', 'Travel Insurance')
    ]

    SOURCE_CHOICES = [
        ('csc', 'CSC'),
        ('website', 'Company Website')
    ]

    user = models.ForeignKey(User, on_delete=models.CASCADE)
    full_name = models.CharField(max_length=100)
    dob = models.DateField()
    gender = models.CharField(max_length=10, choices=[('male', 'Male'), ('female', 'Female'), ('other', 'Other')])
    address = models.TextField()
    mobile = models.CharField(max_length=10)
    email = models.EmailField()
    insurance_type = models.CharField(max_length=20, choices=INSURANCE_TYPES)
    company = models.CharField(max_length=100)
    policy_number = models.CharField(max_length=50)
    nominee_name = models.CharField(max_length=100)
    nominee_relation = models.CharField(max_length=50)
    photo = models.ImageField(upload_to='insurance/photos/')
    id_proof = models.FileField(upload_to='insurance/id_proofs/')
    source = models.CharField(max_length=10, choices=SOURCE_CHOICES)
    bank_name = models.CharField(max_length=100, null=True, blank=True)
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    commission = models.DecimalField(max_digits=10, decimal_places=2)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.full_name} - {self.insurance_type} - {self.policy_number}"

    class Meta:
        ordering = ['-created_at']

class TravelBooking(models.Model):
    TRAVEL_TYPES = [
        ('train', 'Train'),
        ('bus', 'Bus')
    ]

    SOURCE_CHOICES = [
        ('csc', 'CSC'),
        ('website', 'Website')
    ]

    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='travel_bookings')
    booking_number = models.CharField(max_length=20, unique=True)
    travel_type = models.CharField(max_length=10, choices=TRAVEL_TYPES)
    source = models.CharField(max_length=10, choices=SOURCE_CHOICES)
    customer_name = models.CharField(max_length=100)
    source_destination = models.CharField(max_length=100)  # Format: "Source-Destination"
    mobile = models.CharField(max_length=10)
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    commission = models.DecimalField(max_digits=10, decimal_places=2, default=2.00)  # Fixed ₹2 commission
    bank_name = models.CharField(max_length=100, null=True, blank=True)
    status = models.CharField(max_length=20, choices=[
        ('pending', 'Pending'),
        ('confirmed', 'Confirmed'),
        ('cancelled', 'Cancelled')
    ], default='pending')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.customer_name} - {self.booking_number}"

    def save(self, *args, **kwargs):
        if not self.booking_number:
            # Generate booking number
            prefix = 'TRV'
            timestamp = timezone.now().strftime('%Y%m%d%H%M%S')
            self.booking_number = f"{prefix}{timestamp}"
        
        # Set fixed commission of ₹2
        self.commission = Decimal('2.00')
            
        super().save(*args, **kwargs)

    class Meta:
        ordering = ['-created_at']