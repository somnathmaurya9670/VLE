from django.db import migrations

def add_initial_data(apps, schema_editor):
    BillCategory = apps.get_model('category', 'BillCategory')
    BillProvider = apps.get_model('category', 'BillProvider')

    # Create categories
    electricity = BillCategory.objects.create(
        name='Electricity',
        description='Electricity bill payment services'
    )
    
    water = BillCategory.objects.create(
        name='Water',
        description='Water bill payment services'
    )
    
    gas = BillCategory.objects.create(
        name='Gas',
        description='Gas bill payment services'
    )

    # Create providers
    BillProvider.objects.create(
        name='TNEB',
        category=electricity,
        api_endpoint='https://api.tneb.com',
        api_key='dummy_key',
        commission_rate=1.5
    )
    
    BillProvider.objects.create(
        name='Metro Water',
        category=water,
        api_endpoint='https://api.metrowater.com',
        api_key='dummy_key',
        commission_rate=1.0
    )
    
    BillProvider.objects.create(
        name='Indane Gas',
        category=gas,
        api_endpoint='https://api.indane.com',
        api_key='dummy_key',
        commission_rate=2.0
    )

def remove_initial_data(apps, schema_editor):
    BillCategory = apps.get_model('category', 'BillCategory')
    BillProvider = apps.get_model('category', 'BillProvider')
    
    BillProvider.objects.all().delete()
    BillCategory.objects.all().delete()

class Migration(migrations.Migration):
    dependencies = [
        ('category', '0004_billcategory_remove_ledger_topup_alter_ledger_amount_and_more'),
    ]

    operations = [
        migrations.RunPython(add_initial_data, remove_initial_data),
    ] 