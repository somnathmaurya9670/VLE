from django.shortcuts import render,redirect
from . import forms,models
from django.contrib import messages
from .models import Service
from django.contrib.auth.decorators import login_required, user_passes_test
from django.db.models import Sum, F
from decimal import Decimal
import uuid
from django.utils import timezone
from users.models import WalletTransaction, VLEPerformance, Transaction
from django.http import JsonResponse
from django.views.decorators.http import require_POST
from django.db import transaction


@login_required
@user_passes_test(lambda u: u.is_vle)
def electricity_views(request):
    if request.user.is_admin:
        messages.error(request, 'Admins cannot access services. Please use the admin dashboard.')
        return redirect('admin_dashboard')
    if request.method =='POST':
        ans = forms.Ele_form(request.POST)
        if ans.is_valid():
            instance = ans.save(commit=False)
            last_record = models.Ledger.objects.order_by('-id').first()
            last_balance = Decimal(str(last_record.balance)) if last_record else Decimal('0')
            if instance.type=='csc':
                # Check if user has sufficient wallet balance
                if request.user.wallet_balance < instance.amount:
                    messages.warning(request, 'Insufficient wallet balance. Please top up your wallet.')
                    return redirect('category:wallet_topup')
                
                # Deduct amount from wallet
                request.user.wallet_balance = request.user.wallet_balance - instance.amount
                request.user.save()
                
                bal = last_balance - instance.amount
                if bal < 0:
                    messages.warning(request, 'Balance is insufficient. Please top up.')
                    return redirect('category:topup_name')
                instance.balance = bal  
            else:
                bank_name = ans.cleaned_data['bank_name']
                instance.balance = last_balance
                bnk_ins = models.Passbook.objects.create(
                    bank_name=bank_name,
                    transcation_type = 'withdraw',
                    purpose=instance.type,
                    withdraw=instance.amount
                )
                bnk_ins.save()
                instance.connect = bnk_ins                
            instance.save()

            # Update VLE performance if user is a VLE
            if request.user.is_vle:
                today = timezone.now().date()
                # Get the first record for today or create a new one
                try:
                    vle_performance = VLEPerformance.objects.filter(
                        vle=request.user,
                        date=today
                    ).first()
                    if not vle_performance:
                        vle_performance = VLEPerformance.objects.create(
                            vle=request.user,
                            date=today
                        )
                except Exception as e:
                    messages.error(request, f'Error updating performance: {str(e)}')
                    return redirect('category:service_list')

                vle_performance.total_transactions += 1
                vle_performance.total_amount += Decimal(str(instance.amount))
                vle_performance.commission_earned += Decimal(str(instance.commission))

                # Update services provided count
                if not vle_performance.services_provided:
                    vle_performance.services_provided = {}
                
                service_name = 'Electricity Bill'
                if service_name not in vle_performance.services_provided:
                    vle_performance.services_provided[service_name] = {'count': 0, 'amount': 0}
                
                vle_performance.services_provided[service_name]['count'] += 1
                vle_performance.services_provided[service_name]['amount'] += float(instance.amount)  # JSON field can handle float
                
                vle_performance.save()

                # Create individual transaction record
                Transaction.objects.create(
                    vle=request.user,
                    service_type='Electricity Bill',
                    customer_name=instance.customer_name,
                    amount=instance.amount,
                    commission=instance.commission,
                    reference_number=instance.account_no
                )

            return redirect('category:service_list')
    else:
        ans = forms.Ele_form()
    return render(request, "category/electricity.html", {'form': ans})

@login_required
@user_passes_test(lambda u: u.is_vle)
def recharge_views(request):
    if request.user.is_admin:
        messages.error(request, 'Admins cannot access services. Please use the admin dashboard.')
        return redirect('admin_dashboard')
    
    if request.method == 'POST':
        form = forms.RechargeForm(request.POST)
        if form.is_valid():
            try:
                instance = form.save(commit=False)
                amount = Decimal(str(instance.amount))
                commission = Decimal('5.0')  # Fixed commission of 5 Rs per transaction
                
                # Check wallet balance
                if request.user.wallet_balance < amount:
                    messages.warning(request, 'Insufficient wallet balance. Please top up your wallet.')
                    return redirect('category:wallet_topup')
                
                # Deduct from wallet
                request.user.deduct_from_wallet(amount)
                
                # Create wallet transaction
                WalletTransaction.objects.create(
                    user=request.user,
                    amount=amount,
                    transaction_type='debit',
                    description=f'Recharge for {instance.account_no}',
                    reference_id=str(uuid.uuid4()),
                    status='completed'
                )
                
                # Create ledger entry
                last_record = models.Ledger.objects.order_by('-id').first()
                last_balance = Decimal(str(last_record.balance)) if last_record else Decimal('0')
                bal = last_balance - amount + commission
                
                ledger = models.Ledger.objects.create(
                    name='Mobile Recharge',
                    account_no=instance.account_no,
                    customer_name=instance.customer_name,
                    amount=amount,
                    commission=commission,
                    type='csc',  # Set type to 'csc' by default
                    balance=bal
                )
                
                # Create transaction record
                Transaction.objects.create(
                    vle=request.user,
                    service_type='Mobile Recharge',
                    customer_name=instance.customer_name,
                    amount=amount,
                    commission=commission,
                    status='Completed',
                    reference_number=instance.account_no
                )
                
                messages.success(request, f'Recharge of ₹{amount} successful!')
                return redirect('category:service_list')
                
            except ValueError as e:
                messages.error(request, str(e))
                return redirect('category:recharge_name')
    else:
        form = forms.RechargeForm()
    
    return render(request, 'category/recharge.html', {
        'form': form,
        'wallet_balance': request.user.wallet_balance
    })

@login_required
@user_passes_test(lambda u: u.is_vle)
def insurance_views(request):
    if request.user.is_admin:
        messages.error(request, 'Admins cannot access services. Please use the admin dashboard.')
        return redirect('admin_dashboard')
    
    if request.method == 'POST':
        form = forms.Ins_form(request.POST, request.FILES, user=request.user)
        if form.is_valid():
            try:
                with transaction.atomic():
                    # Get form data
                    amount = Decimal(str(form.cleaned_data['amount']))
                    payment_type = form.cleaned_data['type']
                    commission = amount * Decimal('0.02')  # 2% commission
                    
                    # Validate wallet balance for CSC payments
                    if payment_type == 'csc' and request.user.wallet_balance < amount:
                        messages.warning(
                            request,
                            f'Insufficient wallet balance. Required: ₹{amount:.2f}, Available: ₹{request.user.wallet_balance:.2f}'
                        )
                        return redirect('category:wallet_topup')
                    
                    # Generate unique policy number
                    policy_number = f'INS-{timezone.now().strftime("%Y%m%d")}-{uuid.uuid4().hex[:6].upper()}'
                    
                    # Create and save insurance application
                    insurance = models.InsuranceApplication(
                        user=request.user,
                        policy_number=policy_number,
                        full_name=form.cleaned_data['customer_name'],
                        dob=form.cleaned_data['dob'],
                        gender=form.cleaned_data['gender'],
                        address=form.cleaned_data['address'],
                        mobile=form.cleaned_data['mobile'],
                        email=form.cleaned_data['email'],
                        insurance_type=form.cleaned_data['insurance_type'],
                        company=form.cleaned_data['category'],
                        nominee_name=form.cleaned_data['nominee_name'],
                        nominee_relation=form.cleaned_data['nominee_relation'],
                        photo=form.cleaned_data['photo'],
                        id_proof=form.cleaned_data['id_proof'],
                        source=payment_type,
                        bank_name=form.cleaned_data.get('bank_name'),
                        amount=amount,
                        commission=commission,
                        status='Pending'
                    )
                    insurance.save()

                    # Process payment based on type
                    if payment_type == 'csc':
                        # Deduct only the amount from wallet
                        request.user.wallet_balance -= amount
                        # request.user.wallet_balance += commission # Removed commission credit here
                        request.user.save()
                        
                        # Record wallet transaction for debit
                        WalletTransaction.objects.create(
                            user=request.user,
                            amount=amount,
                            transaction_type='debit',
                            description=f'Insurance Premium - {insurance.insurance_type}',
                            reference_id=policy_number,
                            status='completed'
                        )
                        
                        # Removed WalletTransaction for commission credit
                        # WalletTransaction.objects.create(
                        #     user=request.user,
                        #     amount=commission,
                        #     transaction_type='credit',
                        #     description=f'Commission for {policy_number}',
                        #     reference_id=policy_number,
                        #     status='completed'
                        # )
                    else:
                        # Record bank transaction
                        models.Passbook.objects.create(
                            bank_name=form.cleaned_data['bank_name'],
                            transcation_type='withdraw',
                            purpose='Insurance',
                            withdraw=amount,
                            balance=0
                        )

                    # Create ledger entry
                    last_ledger = models.Ledger.objects.order_by('-id').first()
                    last_balance = last_ledger.balance if last_ledger else Decimal('0')
                    new_balance = last_balance - amount + commission if payment_type == 'csc' else last_balance
                    
                    models.Ledger.objects.create(
                        name='Insurance',
                        account_no=policy_number,
                        customer_name=insurance.full_name,
                        amount=amount,
                        commission=commission,
                        type=payment_type,
                        category=insurance.insurance_type,
                        balance=new_balance
                    )

                    # Update VLE performance
                    today = timezone.now().date()
                    try:
                        vle_performance = VLEPerformance.objects.filter(
                            vle=request.user,
                            date=today
                        ).first()
                        if not vle_performance:
                            vle_performance = VLEPerformance.objects.create(
                                vle=request.user,
                                date=today
                            )
                    except Exception as e:
                        messages.error(request, f'Error updating performance: {str(e)}')
                        print(f"Error accessing/creating VLEPerformance: {e}")
                        vle_performance = None

                    if vle_performance:
                        vle_performance.total_transactions += 1
                        vle_performance.total_amount += Decimal(str(amount))
                        vle_performance.commission_earned += Decimal(str(commission))

                        if not vle_performance.services_provided:
                            vle_performance.services_provided = {}
                        
                        service_name = f'Insurance - {insurance.insurance_type}'
                        if service_name not in vle_performance.services_provided:
                            vle_performance.services_provided[service_name] = {'count': 0, 'amount': 0.0}
                        
                        vle_performance.services_provided[service_name]['count'] += 1
                        vle_performance.services_provided[service_name]['amount'] += float(amount)
                        
                        vle_performance.save()

                    # Record VLE transaction
                    Transaction.objects.create(
                        vle=request.user,
                        service_type=f'Insurance - {insurance.insurance_type}',
                        customer_name=insurance.full_name,
                        amount=amount,
                        commission=commission,
                        reference_number=policy_number,
                        status='Completed'
                    )

                    messages.success(
                        request,
                        f'Insurance application for {policy_number} successful! Amount: ₹{amount:.2f}, Commission Earned: ₹{commission:.2f}'
                    )
                    return redirect('category:service_list')

            except Exception as e:
                messages.error(
                    request,
                    f'Error processing insurance application: {str(e)}'
                )
                return redirect('category:insurance_name')
    else:
        form = forms.Ins_form(user=request.user)
    
    return render(request, "category/insurance.html", {
        'form': form,
        'wallet_balance': request.user.wallet_balance
    })

@login_required
@user_passes_test(lambda u: u.is_vle)
def travel_views(request):
    if request.user.is_admin:
        messages.error(request, 'Admins cannot access services. Please use the admin dashboard.')
        return redirect('admin_dashboard')
    if request.method=='POST':
        ans = forms.Travel_form(request.POST)
        if ans.is_valid():
            try:
                instance = ans.save(commit=False)
                instance.user = request.user
                instance.source = ans.cleaned_data['type']
                instance.travel_type = ans.cleaned_data['category']
                
                # Set fixed commission of ₹2
                commission = Decimal('2.00')
                instance.commission = commission
                
                # Calculate total amount to be deducted (amount + commission)
                total_deduction = instance.amount + commission
                
                if instance.source == 'csc':
                    # Check if user has sufficient wallet balance
                    if request.user.wallet_balance < total_deduction:
                        messages.warning(request, f'Insufficient wallet balance. Required: ₹{total_deduction}, Available: ₹{request.user.wallet_balance}. Please top up your wallet.')
                        return redirect('category:wallet_topup')
                    
                    # Deduct total amount from wallet
                    request.user.wallet_balance = request.user.wallet_balance - total_deduction
                    request.user.save()
                    
                    # Create wallet transaction record
                    WalletTransaction.objects.create(
                        user=request.user,
                        amount=total_deduction,
                        transaction_type='debit',
                        description=f'Travel booking for {instance.customer_name}',
                        reference_id=instance.booking_number,
                        status='completed'
                    )
                else:
                    # For website bookings, create passbook entry
                    bank_name = ans.cleaned_data['bank_name']
                    bnk_ins = models.Passbook.objects.create(
                        bank_name=bank_name,
                        transcation_type='withdraw',
                        purpose='Travel Booking',
                        withdraw=total_deduction
                    )
                    bnk_ins.save()
                    instance.bank_name = bank_name
                
                # Save the travel booking
                instance.save()
                
                # Update VLE performance if user is a VLE
                if request.user.is_vle:
                    vle_performance, created = VLEPerformance.objects.get_or_create(
                        vle=request.user,
                        date=timezone.now().date()
                    )
                    vle_performance.total_transactions += 1
                    vle_performance.total_amount += float(instance.amount)
                    vle_performance.commission_earned += float(commission)

                    if not vle_performance.services_provided:
                        vle_performance.services_provided = {}
                    
                    service_name = 'Travel'
                    if service_name not in vle_performance.services_provided:
                        vle_performance.services_provided[service_name] = {'count': 0, 'amount': 0}
                    
                    vle_performance.services_provided[service_name]['count'] += 1
                    vle_performance.services_provided[service_name]['amount'] += float(instance.amount)
                    
                    vle_performance.save()

                    # Create individual transaction record
                    Transaction.objects.create(
                        vle=request.user,
                        service_type='Travel',
                        customer_name=instance.customer_name,
                        amount=instance.amount,
                        commission=commission,
                        reference_number=instance.booking_number
                    )
                
                messages.success(request, f'Travel booking successful! Booking Number: {instance.booking_number}, Amount: ₹{instance.amount}, Commission: ₹{commission}')
                return redirect('category:service_list')
                
            except Exception as e:
                messages.error(request, f'An error occurred: {str(e)}')
                return redirect('category:service_list')
    else:
        ans = forms.Travel_form()
    return render(request, "category/travel.html", {'form': ans})

@login_required
@user_passes_test(lambda u: u.is_vle)
def pan_views(request):
    if request.user.is_admin:
        messages.error(request, 'Admins cannot access services. Please use the admin dashboard.')
        return redirect('admin_dashboard')
    if request.method == 'POST':
        ans = forms.Pan_form(request.POST, request.FILES)
        if ans.is_valid():
            try:
                # Create PAN card application
                pan_application = models.PANCardApplication.objects.create(
                    user=request.user,
                    full_name=ans.cleaned_data['customer_name'],
                    father_name=ans.cleaned_data['father_name'],
                    gender=ans.cleaned_data['gender'],
                    dob=ans.cleaned_data['dob'],
                    address=ans.cleaned_data['address'],
                    mobile=ans.cleaned_data['mobile'],
                    email=ans.cleaned_data['email'],
                    aadhar=ans.cleaned_data['aadhar'],
                    photo=ans.cleaned_data['photo'],
                    aadhar_copy=ans.cleaned_data['aadhar_copy'],
                    source='csc',  # Always set source to CSC
                    pan_type=ans.cleaned_data['category'],
                    bank_name=None,  # No bank name needed for CSC
                )

                # Create ledger entry
                last_record = models.Ledger.objects.order_by('-id').first()
                last_balance = Decimal(str(last_record.balance)) if last_record else Decimal('0')
                
                # Check if user has sufficient balance
                if request.user.wallet_balance < pan_application.amount:
                    messages.warning(request, 'Balance is insufficient. Please top up your wallet.')
                    pan_application.delete()  # Delete the application if balance is insufficient
                    return redirect('category:wallet_topup')
                
                # Update wallet balance
                request.user.wallet_balance = request.user.wallet_balance - pan_application.amount + pan_application.commission
                request.user.save()
                
                bal = last_balance - pan_application.amount + pan_application.commission

                # Create ledger entry
                ledger = models.Ledger.objects.create(
                    name='PAN Card',
                    account_no=pan_application.application_number,
                    customer_name=pan_application.full_name,
                    amount=pan_application.amount,
                    commission=pan_application.commission,
                    type='csc',  # Always set type to CSC
                    category=pan_application.pan_type,
                    balance=bal
                )

                # Update VLE performance if user is a VLE
                if request.user.is_vle:
                    vle_performance, created = VLEPerformance.objects.get_or_create(
                        vle=request.user,
                        date=timezone.now().date()
                    )
                    vle_performance.total_transactions += 1
                    vle_performance.total_amount += pan_application.amount
                    vle_performance.commission_earned += pan_application.commission

                    # Update services provided count
                    if not vle_performance.services_provided:
                        vle_performance.services_provided = {}
                    
                    service_name = 'PAN Card'
                    if service_name not in vle_performance.services_provided:
                        vle_performance.services_provided[service_name] = {'count': 0, 'amount': 0}
                    
                    vle_performance.services_provided[service_name]['count'] += 1
                    vle_performance.services_provided[service_name]['amount'] += pan_application.amount
                    
                    vle_performance.save()

                    # Create individual transaction record
                    Transaction.objects.create(
                        vle=request.user,
                        service_type='PAN Card',
                        customer_name=pan_application.full_name,
                        amount=pan_application.amount,
                        commission=pan_application.commission,
                        reference_number=pan_application.application_number
                    )

                messages.success(request, f'PAN Card application submitted successfully! Application Number: {pan_application.application_number}')
                return redirect('category:service_list')

            except Exception as e:
                messages.error(request, f'An error occurred: {str(e)}')
                return redirect('category:service_list')
    else:
        ans = forms.Pan_form()
    return render(request, "category/pan.html", {'form': ans})

def topup_views(request):
    if request.method=='POST':
        ans = forms.WalletTopupForm(request.POST)
        if ans.is_valid():
            instance = ans.save(commit=False)
            last_record = models.Ledger.objects.order_by('-id').first()
            if last_record:
                last_balance = Decimal(str(last_record.balance))
            else:
                last_balance = Decimal('0')
            instance.balance = last_balance + instance.amount 
            bank_name = ans.cleaned_data['bank_name'] 
            bnk_ins = models.Passbook.objects.create(
                bank_name=bank_name,
                transcation_type = 'deposit',
                purpose='topup',
                deposit=instance.amount
            )
            bnk_ins.save()
            instance.connect = bnk_ins   
            instance.save()
            return redirect('category:service_list')
    else:
        ans = forms.WalletTopupForm()
    return render(request, "category/topup.html", {'form': ans})

@login_required
@user_passes_test(lambda u: u.is_vle)
def esevai_views(request):
    if request.user.is_admin:
        messages.error(request, 'Admins cannot access services. Please use the admin dashboard.')
        return redirect('admin_dashboard')
    if request.method=='POST':
        ans = forms.Esevai_form(request.POST)
        if ans.is_valid():
            instance = ans.save(commit=False)
            last_record = models.Ledger.objects.order_by('-id').first()
            last_balance = Decimal(str(last_record.balance)) if last_record else Decimal('0')
            
            if instance.type == 'csc':
                # Check if user has sufficient wallet balance
                if request.user.wallet_balance < instance.amount:
                    messages.warning(request, 'Insufficient wallet balance. Please top up your wallet.')
                    return redirect('category:wallet_topup')
                
                # Deduct amount from wallet
                request.user.wallet_balance = request.user.wallet_balance - instance.amount
                request.user.save()
                
                bal = last_balance - instance.amount
                if bal < 0:
                    messages.warning(request, 'Balance is insufficient. Please top up.')
                    return redirect('category:topup_name')
                instance.balance = bal
                
                # Update VLE performance if user is a VLE
                if request.user.is_vle:
                    vle_performance, created = VLEPerformance.objects.get_or_create(
                        vle=request.user,
                        date=timezone.now().date()
                    )
                    vle_performance.total_transactions += 1
                    vle_performance.total_amount += Decimal(str(instance.amount))
                    vle_performance.commission_earned += Decimal(str(instance.commission))
                    
                    # Update services provided count
                    if not vle_performance.services_provided:
                        vle_performance.services_provided = {}
                    
                    service_name = 'E-Sevai Service'
                    if service_name not in vle_performance.services_provided:
                        vle_performance.services_provided[service_name] = {'count': 0, 'amount': 0.0}
                    
                    vle_performance.services_provided[service_name]['count'] += 1
                    vle_performance.services_provided[service_name]['amount'] += float(instance.amount)
                    
                    vle_performance.save()
                    
                    # Create individual transaction record
                    Transaction.objects.create(
                        vle=request.user,
                        service_type='E-Sevai Service',
                        customer_name=instance.customer_name,
                        amount=instance.amount,
                        commission=instance.commission,
                        reference_number=instance.account_no
                    )
                    
            else:
                bank_name = ans.cleaned_data['bank_name']
                instance.balance = last_balance
                bnk_ins = models.Passbook.objects.create(
                    bank_name=bank_name,
                    transcation_type='withdraw',
                    purpose=instance.category,
                    withdraw=instance.amount
                )
                bnk_ins.save()
                instance.connect = bnk_ins
                
            instance.save()
            messages.success(request, f'E-Sevai service request submitted successfully! Commission: ₹{instance.commission}')
            return redirect('category:service_list')
            
    else:
        ans = forms.Esevai_form()
    return render(request, "esevai.html", {'form': ans})

def enrollment_views(request):
    if request.method=='POST':
        ans = forms.Enrollment_form(request.POST)
        if ans.is_valid():
            try:
                instance = ans.save(commit=False)
                last_record = models.Ledger.objects.order_by('-id').first()
                last_balance = Decimal(str(last_record.balance)) if last_record else Decimal('0')
                
                # Check if user has sufficient wallet balance
                if request.user.wallet_balance < instance.amount:
                    messages.warning(request, 'Insufficient wallet balance. Please top up your wallet.')
                    return redirect('category:wallet_topup')
                
                # Deduct amount from wallet
                request.user.wallet_balance = request.user.wallet_balance - instance.amount
                request.user.save()
                
                # Calculate new balance
                instance.balance = last_balance - instance.amount
                
                # Create passbook entry
                bank_name = ans.cleaned_data['bank_name']
                bnk_ins = models.Passbook.objects.create(
                    bank_name=bank_name,
                    transcation_type='withdraw',
                    purpose=instance.category,
                    withdraw=instance.amount
                )
                bnk_ins.save()
                
                # Set connection and save
                instance.connect = bnk_ins
                instance.save()
                
                # Create transaction record
                Transaction.objects.create(
                    vle=request.user,
                    service_type='Enrollment',
                    customer_name=instance.customer_name,
                    amount=instance.amount,
                    commission=Decimal('0'),  # No commission for enrollment
                    status='Completed',
                    reference_number=instance.account_no
                )
                
                messages.success(request, f'Enrollment successful! Amount: ₹{instance.amount}')
                return redirect('category:service_list')
                
            except Exception as e:
                messages.error(request, f'An error occurred: {str(e)}')
                return redirect('category:enrollment_name')
    else:
        ans = forms.Enrollment_form()
    
    return render(request, "category/enrollment.html", {
        'form': ans,
        'wallet_balance': request.user.wallet_balance
    })

def bank_views(request):
    if request.method=='POST':
        ans = forms.Bank_form(request.POST)
        if ans.is_valid():
            instance=ans.save(commit=False)
            last_record = models.Passbook.objects.filter(bank_name=instance.bank_name).order_by('-id').first()
            if last_record:
                last_balance = Decimal(str(last_record.balance))
            else:
                last_balance = Decimal('0')
            
            if instance.transcation_type=='deposit':
                deposit = Decimal(str(ans.cleaned_data['deposit'] or '0'))
                instance.deposit = deposit
                instance.withdraw = None
                instance.balance = last_balance + deposit
            else:
                withdraw = Decimal(str(ans.cleaned_data['withdraw'] or '0'))
                instance.withdraw = withdraw
                instance.deposit = None
                instance.balance = last_balance - withdraw
                
            instance.save()
            return redirect('category:service_list')
            
    else:
        ans = forms.Bank_form()
    return render(request,"bank.html",{'form':ans})

@login_required
@user_passes_test(lambda u: u.is_vle)
def service_list(request):
    if request.user.is_admin:
        messages.error(request, 'Admins cannot access services. Please use the admin dashboard.')
        return redirect('admin_dashboard')
    return render(request, 'category/service_list.html')

@login_required
@user_passes_test(lambda u: u.is_vle)
def bill_payment(request):
    if request.user.is_admin:
        messages.error(request, 'Admins cannot access services. Please use the admin dashboard.')
        return redirect('admin_dashboard')
    
    if request.method == 'POST':
        form = forms.BillPaymentForm(request.POST)
        if form.is_valid():
            try:
                bill_payment = form.save(commit=False)
                bill_payment.user = request.user
                bill_payment.transaction_id = str(uuid.uuid4())
                
                # Fixed commission of 1.9 Rs per transaction
                commission = Decimal('1.9')
                bill_payment.commission = commission
                
                # Deduct amount from wallet
                request.user.deduct_from_wallet(bill_payment.amount)
                
                # Create wallet transaction
                WalletTransaction.objects.create(
                    user=request.user,
                    amount=bill_payment.amount,
                    transaction_type='debit',
                    description=f'Bill payment to {bill_payment.provider.name}',
                    reference_id=bill_payment.transaction_id,
                    status='completed'
                )
                
                # Create ledger entry
                ledger = models.Ledger.objects.create(
                    name='Bill Payment',
                    amount=bill_payment.amount,
                    commission=commission,
                    type='bill',
                    category=bill_payment.provider.category.name,
                    balance=request.user.wallet_balance,
                    bill_payment=bill_payment
                )
                
                # Create transaction record
                Transaction.objects.create(
                    vle=request.user,
                    service_type='Bill Payment',
                    customer_name=bill_payment.customer_name,
                    amount=bill_payment.amount,
                    commission=commission,
                    status='Completed',
                    reference_number=bill_payment.transaction_id
                )
                
                messages.success(request, f'Bill payment of ₹{bill_payment.amount} successful!')
                return redirect('category:service_list')
                
            except ValueError as e:
                messages.error(request, str(e))
                return redirect('category:bill_payment')
    else:
        form = forms.BillPaymentForm()
    
    return render(request, 'category/bill_payment.html', {
        'form': form,
        'wallet_balance': request.user.wallet_balance
    })

@login_required
def wallet_topup(request):
    if request.method == 'POST':
        form = forms.WalletTopupForm(request.POST)
        if form.is_valid():
            try:
                amount = form.cleaned_data['amount']
                bank_name = form.cleaned_data['bank_name']
                
                # Create passbook entry
                passbook = models.Passbook.objects.create(
                    bank_name=bank_name,
                    transcation_type='deposit',
                    purpose='Wallet Topup',
                    deposit=amount,
                    balance=0  # Will be calculated in save method
                )
                
                # Add amount to wallet
                request.user.add_to_wallet(amount)
                
                # Create wallet transaction
                WalletTransaction.objects.create(
                    user=request.user,
                    amount=amount,
                    transaction_type='credit',
                    description='Wallet topup',
                    reference_id=str(uuid.uuid4()),
                    status='completed'
                )
                
                # Create ledger entry
                models.Ledger.objects.create(
                    name='Wallet Topup',
                    amount=amount,
                    type='topup',
                    balance=request.user.wallet_balance,
                    connect=passbook
                )
                
                messages.success(request, f'Wallet topup of ₹{amount} successful!')
                return redirect('category:wallet_balance')
                
            except ValueError as e:
                messages.error(request, str(e))
                return redirect('category:wallet_topup')
    else:
        form = forms.WalletTopupForm()
    
    return render(request, 'category/wallet_topup.html', {
        'form': form,
        'wallet_balance': request.user.wallet_balance
    })

@login_required
def wallet_balance(request):
    transactions = WalletTransaction.objects.filter(user=request.user).order_by('-created_at')
    return render(request, 'category/wallet_balance.html', {
        'balance': request.user.wallet_balance,
        'transactions': transactions
    })

@require_POST
@login_required
def get_wallet_balance(request):
    return JsonResponse({
        'balance': str(request.user.wallet_balance)
    })

@require_POST
@login_required
def get_recent_transactions(request):
    transactions = WalletTransaction.objects.filter(user=request.user).order_by('-created_at')[:5]
    data = [{
        'date': t.created_at.strftime('%d %b %Y %H:%M'),
        'type': t.get_transaction_type_display(),
        'amount': str(t.amount),
        'description': t.description,
        'status': t.get_status_display()
    } for t in transactions]
    return JsonResponse({'transactions': data})

@login_required
def bill_payment_history(request):
    payments = models.BillPayment.objects.filter(user=request.user).order_by('-created_at')
    return render(request, 'category/bill_payment_history.html', {'payments': payments})