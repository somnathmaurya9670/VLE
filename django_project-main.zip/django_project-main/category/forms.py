from django import forms
from django.forms import ModelForm
from . import models
from decimal import Decimal
import re

class BillPaymentForm(ModelForm):
    class Meta:
        model = models.BillPayment
        fields = ['provider', 'bill_number', 'amount']
        labels = {
            'provider': 'Bill Provider',
            'bill_number': 'Bill Number',
            'amount': 'Amount'
        }

    def clean_amount(self):
        amount = self.cleaned_data.get('amount')
        if amount is None:
            raise forms.ValidationError("Amount is required")
        if amount <= 0:
            raise forms.ValidationError("Amount must be greater than zero")
        return amount

class WalletTopupForm(ModelForm):
    bank_name = forms.ChoiceField(choices=models.Passbook.bnk_name, required=True, widget=forms.Select())
    
    class Meta:
        model = models.Ledger
        fields = ['name', 'amount']
        labels = {
            'amount': 'Enter the amount to top up'
        }
        widgets = {
            'name': forms.TextInput(attrs={'readonly': 'readonly', 'value': 'Wallet Topup'})
        }

    def clean_amount(self):
        amount = self.cleaned_data.get('amount')
        if amount is None:
            raise forms.ValidationError("Amount is required")
        if amount <= 0:
            raise forms.ValidationError("Amount must be greater than zero")
        if amount > 50000:
            raise forms.ValidationError("Maximum topup amount is ₹50,000")
        return amount

class Ele_form(ModelForm):
    type_choice = [
        ('csc','CSC'),
        ('tneb','TNEB')
    ]

    type = forms.ChoiceField(choices=type_choice, widget=forms.Select(), label='Choose the website')
    bank_name = forms.ChoiceField(choices=models.Passbook.bnk_name, required=False, widget=forms.Select())

    class Meta:
        model = models.Ledger
        fields = ['name','account_no','customer_name','amount','type']
        labels = {
            'name' : 'Enter the category',
            'account_no' : 'Enter the eb number',
            'customer_name': 'Enter the customer name',
            'amount' : 'Enter the eb bill amount',
            'type':'Choose the website'
        }
        widgets = {
            'name': forms.TextInput(attrs={'readonly': 'readonly', 'value': 'Electricity'})
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        if self.data.get('type') == 'tneb':
            self.fields['bank_name'].required = True
        else:
            self.fields['bank_name'].widget = forms.HiddenInput()
        
    '''def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for field_name in self.fields:
            self.fields[field_name].required = True
            self.fields[field_name].error_messages = {
                'required': f'{self.fields[field_name].label} is required.'
            }'''

class Rch_form(ModelForm):
    type_choice = [
        ('csc', 'CSC'),
        ('website', 'Brand Website')
    ]
    brand_choice = [
        ('jio', 'JIO'),
        ('airtel', 'AIRTEL'),
        ('vi', 'VI'),
        ('bsnl', 'BSNL'),
        ('dth', 'DTH')
    ]

    type = forms.ChoiceField(choices=type_choice, widget=forms.Select(), label='Choose the website')
    category = forms.ChoiceField(choices=brand_choice, widget=forms.Select(), label='Choose the brand name')
    bank_name = forms.ChoiceField(choices=models.Passbook.bnk_name, required=False, widget=forms.Select())

    class Meta:
        model = models.Ledger
        fields = ['name', 'category', 'account_no', 'amount', 'commission', 'type', 'mobile']
        exclude = ['mobile']
        labels = {
            'name': 'Enter the category',
            'account_no': 'Enter the mobile number',
            'amount': 'Enter the recharge amount',
            'commission': 'Enter the commission amount',
        }
        widgets = {
            'name': forms.TextInput(attrs={'readonly': 'readonly', 'value': 'Recharge'}),
            'amount': forms.NumberInput(attrs={'min': '0', 'step': '0.01'}),
            'commission': forms.NumberInput(attrs={'min': '0', 'step': '0.01'})
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        if self.data.get('type') == 'website':
            self.fields['bank_name'].required = True
        else:
            self.fields['bank_name'].widget = forms.HiddenInput()

    def clean_amount(self):
        amount = self.cleaned_data.get('amount')
        if amount is None or amount <= 0:
            raise forms.ValidationError("Amount must be greater than zero")
        return amount

    def clean_commission(self):
        commission = self.cleaned_data.get('commission')
        if commission is None or commission < 0:
            raise forms.ValidationError("Commission cannot be negative")
        return commission

    def clean(self):
        cleaned_data = super().clean()
        amount = cleaned_data.get('amount')
        commission = cleaned_data.get('commission')
        
        if amount and commission and commission >= amount:
            raise forms.ValidationError("Commission cannot be greater than or equal to the recharge amount")
            
        return cleaned_data

class Ins_form(forms.ModelForm):
    insurance_type_choice = [
        ('life', 'Life Insurance'),
        ('health', 'Health Insurance'),
        ('motor', 'Motor Insurance'),
        ('home', 'Home Insurance'),
        ('travel', 'Travel Insurance')
    ]

    insurance_type = forms.ChoiceField(choices=insurance_type_choice, widget=forms.Select(attrs={'class': 'form-select'}), label='Insurance Type')
    bank_name = forms.ChoiceField(choices=models.Passbook.bnk_name, required=False, widget=forms.Select(attrs={'class': 'form-select'}))
    dob = forms.DateField(widget=forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}), label='Date of Birth')
    gender = forms.ChoiceField(choices=[('male', 'Male'), ('female', 'Female'), ('other', 'Other')], widget=forms.Select(attrs={'class': 'form-select'}), label='Gender')
    nominee_name = forms.CharField(max_length=100, label="Nominee's Name", widget=forms.TextInput(attrs={'class': 'form-control'}))
    nominee_relation = forms.CharField(max_length=50, label="Nominee's Relation", widget=forms.TextInput(attrs={'class': 'form-control'}))
    address = forms.CharField(widget=forms.Textarea(attrs={'rows': 3, 'class': 'form-control'}), label='Address')
    email = forms.EmailField(label='Email Address', widget=forms.EmailInput(attrs={'class': 'form-control'}))
    photo = forms.ImageField(label='Passport Size Photo', widget=forms.FileInput(attrs={'class': 'form-control'}))
    id_proof = forms.FileField(label='ID Proof', widget=forms.FileInput(attrs={'class': 'form-control'}))
    customer_name = forms.CharField(max_length=100, label='Full Name', widget=forms.TextInput(attrs={'class': 'form-control'}))
    mobile = forms.CharField(max_length=10, label='Mobile Number', widget=forms.TextInput(attrs={'class': 'form-control', 'pattern': '[0-9]{10}', 'title': 'Enter 10-digit mobile number'}))
    amount = forms.DecimalField(max_digits=10, decimal_places=2, label='Premium Amount', widget=forms.NumberInput(attrs={'min': '0', 'step': '0.01', 'class': 'form-control'}))
    category = forms.CharField(max_length=100, label='Insurance Company', widget=forms.TextInput(attrs={'class': 'form-control'}))
    account_no = forms.CharField(max_length=50, label='Policy Number', widget=forms.TextInput(attrs={'class': 'form-control'}))
    type = forms.CharField(widget=forms.HiddenInput(), initial='csc')
    commission = forms.DecimalField(max_digits=10, decimal_places=2, required=False, widget=forms.HiddenInput())

    class Meta:
        model = models.InsuranceApplication
        fields = ['customer_name', 'dob', 'gender', 'address', 'mobile', 'email', 
                 'insurance_type', 'category', 'account_no', 'nominee_name', 
                 'nominee_relation', 'photo', 'id_proof', 'amount', 'commission']

    def __init__(self, *args, **kwargs):
        self.user = kwargs.pop('user', None)
        super().__init__(*args, **kwargs)
        self.fields['commission'].initial = 0
        self.fields['type'].initial = 'csc'

    def clean_amount(self):
        amount = self.cleaned_data.get('amount')
        if amount is None or amount <= 0:
            raise forms.ValidationError("Amount must be greater than zero")
        
        # Check if user has sufficient wallet balance
        if self.user and self.user.wallet_balance < amount:
            raise forms.ValidationError("Insufficient wallet balance")
        
        # Calculate commission (2% of premium amount)
        self.cleaned_data['commission'] = amount * Decimal('0.02')
        return amount

    def clean_photo(self):
        photo = self.cleaned_data.get('photo')
        if photo:
            if photo.size > 2*1024*1024:  # 2MB limit
                raise forms.ValidationError('Photo size should not exceed 2MB')
            if not photo.content_type.startswith('image/'):
                raise forms.ValidationError('Please upload an image file')
        return photo

    def clean_id_proof(self):
        id_proof = self.cleaned_data.get('id_proof')
        if id_proof:
            if id_proof.size > 5*1024*1024:  # 5MB limit
                raise forms.ValidationError('ID proof size should not exceed 5MB')
            if not id_proof.content_type in ['application/pdf', 'image/jpeg', 'image/png']:
                raise forms.ValidationError('Please upload a PDF, JPEG, or PNG file')
        return id_proof

    def clean_mobile(self):
        mobile = self.cleaned_data.get('mobile')
        if not mobile.isdigit() or len(mobile) != 10:
            raise forms.ValidationError('Please enter a valid 10-digit mobile number')
        return mobile

    def clean_email(self):
        email = self.cleaned_data.get('email')
        if email and not email.endswith(('.com', '.in', '.org', '.net')):
            raise forms.ValidationError('Please enter a valid email address')
        return email

    def clean_customer_name(self):
        name = self.cleaned_data.get('customer_name')
        if not name.replace(' ', '').isalpha():
            raise forms.ValidationError('Name should contain only letters and spaces')
        return name

    def clean_nominee_name(self):
        name = self.cleaned_data.get('nominee_name')
        if not name.replace(' ', '').isalpha():
            raise forms.ValidationError('Nominee name should contain only letters and spaces')
        return name

    def clean_nominee_relation(self):
        relation = self.cleaned_data.get('nominee_relation')
        if not relation.replace(' ', '').isalpha():
            raise forms.ValidationError('Nominee relation should contain only letters and spaces')
        return relation

    def save(self, commit=True):
        instance = super().save(commit=False)
        if commit:
            instance.save()
        return instance

class Pan_form(ModelForm):
    website_choice = [
        ('uti', 'UTI'),
        ('nsdl', 'NSDL')
    ]
    gender_choice = [
        ('male', 'Male'),
        ('female', 'Female'),
        ('transgender', 'Transgender')
    ]

    category = forms.ChoiceField(choices=website_choice, widget=forms.Select(), label='Select PAN Type')
    bank_name = forms.ChoiceField(choices=models.Passbook.bnk_name, required=False, widget=forms.HiddenInput())
    gender = forms.ChoiceField(choices=gender_choice, widget=forms.Select(), label='Gender')
    dob = forms.DateField(widget=forms.DateInput(attrs={'type': 'date'}), label='Date of Birth')
    email = forms.EmailField(label='Email Address')
    aadhar = forms.CharField(max_length=12, min_length=12, label='Aadhar Number')
    photo = forms.ImageField(label='Passport Size Photo')
    aadhar_copy = forms.FileField(label='Aadhar Card Copy')
    father_name = forms.CharField(max_length=100, label="Father's Name")
    address = forms.CharField(widget=forms.Textarea(attrs={'rows': 3}), label='Address')

    class Meta:
        model = models.Ledger
        fields = ['name', 'account_no', 'customer_name', 'mobile', 'category']
        exclude = ['amount', 'commission', 'type']
        labels = {
            'account_no': 'Application Number',
            'customer_name': 'Full Name',
            'mobile': 'Mobile Number',
        }
        widgets = {
            'name': forms.TextInput(attrs={'readonly': 'readonly', 'value': 'PAN Card'}),
            'mobile': forms.TextInput(attrs={'pattern': '[0-9]{10}', 'title': 'Enter 10-digit mobile number'}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['bank_name'].widget = forms.HiddenInput()

    def clean_mobile(self):
        mobile = self.cleaned_data.get('mobile')
        if not mobile.isdigit() or len(mobile) != 10:
            raise forms.ValidationError('Please enter a valid 10-digit mobile number')
        return mobile

    def clean_aadhar(self):
        aadhar = self.cleaned_data.get('aadhar')
        if not aadhar.isdigit() or len(aadhar) != 12:
            raise forms.ValidationError('Please enter a valid 12-digit Aadhar number')
        return aadhar

    def clean_photo(self):
        photo = self.cleaned_data.get('photo')
        if photo:
            if photo.size > 2*1024*1024:  # 2MB limit
                raise forms.ValidationError('Photo size should not exceed 2MB')
            if not photo.content_type.startswith('image/'):
                raise forms.ValidationError('Please upload an image file')
        return photo

    def clean_aadhar_copy(self):
        aadhar_copy = self.cleaned_data.get('aadhar_copy')
        if aadhar_copy:
            if aadhar_copy.size > 5*1024*1024:  # 5MB limit
                raise forms.ValidationError('Aadhar copy size should not exceed 5MB')
            if not aadhar_copy.content_type in ['application/pdf', 'image/jpeg', 'image/png']:
                raise forms.ValidationError('Please upload a PDF, JPEG, or PNG file')
        return aadhar_copy

    def clean(self):
        cleaned_data = super().clean()
        type = cleaned_data.get('type')
        bank_name = cleaned_data.get('bank_name')

        if type == 'website' and not bank_name:
            self.add_error('bank_name', 'Bank name is required for website payment')
            
        return cleaned_data

class Travel_form(ModelForm):
    type_choice = [
        ('csc','CSC'),
        ('website','Website')
    ]
    website_choice = [
        ('train','TRAIN'),
        ('bus','BUS')
    ]

    type = forms.ChoiceField(choices=type_choice, widget=forms.Select(), label='Select source')
    category = forms.ChoiceField(choices=website_choice, widget=forms.Select(), label='Select travel type')
    bank_name = forms.ChoiceField(choices=models.Passbook.bnk_name, required=False, widget=forms.Select())

    class Meta:
        model = models.TravelBooking
        fields = ['travel_type', 'source', 'customer_name', 'source_destination', 'mobile', 'amount', 'bank_name']
        labels = {
            'travel_type': 'Travel Type',
            'source': 'Booking Source',
            'customer_name': 'Customer Name',
            'source_destination': 'Source-Destination',
            'mobile': 'Mobile Number',
            'amount': 'Amount',
            'bank_name': 'Bank Name'
        }

        widgets = {
            'source_destination': forms.TextInput(attrs={'placeholder': 'e.g., VM-MS'}),
            'amount': forms.NumberInput(attrs={'min': '0', 'step': '0.01'})
        }
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        if self.data.get('source') == 'website':
            self.fields['bank_name'].required = True
        else:
            self.fields['bank_name'].widget = forms.HiddenInput()

class Esevai_form(ModelForm):
    type_choice = [
        ('csc','CSC'),
        ('tnega','TNEGA')
    ]
    website_choice = [
        ('community','community'),
        ('nativity','nativity'),
        ('income','income'),
        ('first graduate','first graduate'),
        ('obc','obc'),
        ('old age pension','old age pension'),
        ('widow','widow'),
        ('widow pension','widow pension'),
        ('small farmer','small farmer'),
        ('legal heir','legal heir')
    ]

    type = forms.ChoiceField(choices=type_choice, widget=forms.Select(), label='Select source')
    category = forms.ChoiceField(choices=website_choice, widget=forms.Select(), label='Select certificate name')
    bank_name = forms.ChoiceField(choices=models.Passbook.bnk_name, required=False, widget=forms.Select())
    
    class Meta:
        model = models.Ledger
        fields = ['name','account_no','customer_name','category','mobile','amount','type']
        labels = {
            'account_no':'Enter the certificate no',
            'mobile':'Enter the customer mobile no', 
            'customer_name':'Enter the customer name'   
        }

        widgets = {
            'name': forms.TextInput(attrs={'readonly': 'readonly', 'value': 'Esevai'}),
            'account_no': forms.TextInput(attrs={'placeholder': 'e.g., TN-1234567890'})
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        if self.data.get('type') == 'tnega':
            self.fields['bank_name'].required = True
        else:
            self.fields['bank_name'].widget = forms.HiddenInput()

    def save(self, commit=True):
        instance = super().save(commit=False)
        instance.commission = Decimal('1.5')  # Set fixed commission of ₹1.5
        if commit:
            instance.save()
        return instance

class Enrollment_form(ModelForm):
    bank_name = forms.ChoiceField(choices=models.Passbook.bnk_name, required=True, widget=forms.Select())

    class Meta:
        model = models.Ledger
        fields = ['name','category','customer_name','account_no','type','mobile','amount']
        labels = {
            'category':'Enter the enrollment name:', 
            'customer_name':'Enter the customer name',  
            'account_no':'Enter the user id',
            'type':'Enter the password',
            'mobile':'Enter the customer mobile no', 
            'amount':'Enter the amount paid',
        }
        widgets = {
            'name': forms.TextInput(attrs={'readonly': 'readonly', 'value': 'Enrollment'})
        }

class Bank_form(ModelForm):
    class Meta:
        model = models.Passbook
        fields = ['bank_name','transcation_type','purpose','deposit','withdraw']
        labels = {
            'bank_name': 'Select Bank',
            'transcation_type': 'Select Transaction Type',
            'purpose': 'Enter Purpose',
            'deposit': 'Enter Deposit Amount',
            'withdraw': 'Enter Withdrawal Amount'
        }

    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs)
        self.fields['deposit'].required = False
        self.fields['withdraw'].required = False
        self.fields['deposit'].widget = forms.HiddenInput()
        self.fields['withdraw'].widget = forms.HiddenInput()

        if 'transcation_type' in self.data:
            transcation_type = self.data.get('transcation_type')
            if transcation_type=='deposit':
                self.fields['deposit'].widget = forms.NumberInput()
                self.fields['deposit'].required = True
            else:
                self.fields['withdraw'].widget = forms.NumberInput()
                self.fields['withdraw'].required = True

    def clean(self):
        cleaned_data = super().clean()
        transcation_type = cleaned_data.get('transcation_type')
        deposit = cleaned_data.get('deposit')
        withdraw = cleaned_data.get('withdraw')

        if transcation_type == 'deposit' and not deposit:
            raise forms.ValidationError("Deposit amount is required")
        elif transcation_type == 'withdraw' and not withdraw:
            raise forms.ValidationError("Withdrawal amount is required")

        if deposit and deposit <= 0:
            raise forms.ValidationError("Deposit amount must be greater than zero")
        if withdraw and withdraw <= 0:
            raise forms.ValidationError("Withdrawal amount must be greater than zero")

        return cleaned_data

class RechargeForm(ModelForm):
    class Meta:
        model = models.Ledger
        fields = ['account_no', 'customer_name', 'amount', 'category']
        labels = {
            'account_no': 'Mobile Number',
            'customer_name': 'Customer Name',
            'amount': 'Recharge Amount',
            'category': 'Service Provider'
        }

    def clean_account_no(self):
        account_no = self.cleaned_data.get('account_no')
        if not re.match(r'^[6-9]\d{9}$', str(account_no)):
            raise forms.ValidationError("Please enter a valid 10-digit mobile number")
        return account_no

    def clean_customer_name(self):
        customer_name = self.cleaned_data.get('customer_name')
        if not customer_name:
            raise forms.ValidationError("Customer name is required")
        if len(customer_name) < 3:
            raise forms.ValidationError("Customer name must be at least 3 characters long")
        return customer_name

    def clean_amount(self):
        amount = self.cleaned_data.get('amount')
        if amount is None:
            raise forms.ValidationError("Amount is required")
        if amount < 10:
            raise forms.ValidationError("Minimum recharge amount is ₹10")
        if amount > 1000:
            raise forms.ValidationError("Maximum recharge amount is ₹1,000")
        return amount