from django.urls import path
from . import views

app_name = 'category'

urlpatterns = [
    path('', views.service_list, name='service_list'),
    path('electricity/', views.electricity_views, name='electricity_name'),
    path('recharge/', views.recharge_views, name='recharge_name'),
    path('pan/', views.pan_views, name='pan_name'),
    path('esevai/', views.esevai_views, name='esevai_name'),
    path('enrollment/', views.enrollment_views, name='enrollment_name'),
    path('insurance/', views.insurance_views, name='insurance_name'),
    path('travel/', views.travel_views, name='travel_name'),
    path('bank/', views.bank_views, name='bank_name'),
    path('topup/', views.topup_views, name='topup_name'),
    path('bill-payment/', views.bill_payment, name='bill_payment'),
    path('bill-payment/history/', views.bill_payment_history, name='bill_payment_history'),
    path('wallet/topup/', views.wallet_topup, name='wallet_topup'),
    path('wallet/balance/', views.wallet_balance, name='wallet_balance'),
    path('wallet/balance/update/', views.get_wallet_balance, name='get_wallet_balance'),
    path('wallet/transactions/update/', views.get_recent_transactions, name='get_recent_transactions'),
]
