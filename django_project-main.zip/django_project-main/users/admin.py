from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from .models import User, WalletTransaction, Transaction, VLEPerformance

class WalletTransactionInline(admin.TabularInline):
    model = WalletTransaction
    extra = 0
    readonly_fields = ('created_at',)
    fields = ('amount', 'transaction_type', 'description', 'reference_id', 'status', 'created_at')
    ordering = ('-created_at',)

class TransactionInline(admin.TabularInline):
    model = Transaction
    extra = 0
    readonly_fields = ('date',)
    fields = ('service_type', 'customer_name', 'amount', 'commission', 'status', 'reference_number', 'date')
    ordering = ('-date',)

class VLEPerformanceInline(admin.TabularInline):
    model = VLEPerformance
    extra = 0
    readonly_fields = ('date',)
    fields = ('date', 'total_transactions', 'total_amount', 'commission_earned')
    ordering = ('-date',)

@admin.register(User)
class CustomUserAdmin(UserAdmin):
    list_display = ('username', 'email', 'phone_number', 'wallet_balance', 'is_vle', 'is_admin', 'kyc_status')
    list_filter = ('is_vle', 'is_admin', 'kyc_status')
    search_fields = ('username', 'email', 'phone_number', 'center_name', 'center_code')
    readonly_fields = ('wallet_balance',)
    fieldsets = (
        (None, {'fields': ('username', 'password')}),
        ('Personal info', {'fields': ('first_name', 'last_name', 'email', 'phone_number')}),
        ('VLE Info', {'fields': ('center_name', 'center_code', 'district', 'state')}),
        ('Wallet', {'fields': ('wallet_balance',)}),
        ('KYC', {'fields': ('kyc_verified', 'kyc_document', 'kyc_status')}),
        ('Permissions', {'fields': ('is_active', 'is_staff', 'is_superuser', 'is_vle', 'is_admin', 'groups', 'user_permissions')}),
        ('Important dates', {'fields': ('last_login', 'date_joined')}),
    )
    inlines = [WalletTransactionInline, TransactionInline, VLEPerformanceInline]

@admin.register(WalletTransaction)
class WalletTransactionAdmin(admin.ModelAdmin):
    list_display = ('user', 'amount', 'transaction_type', 'description', 'reference_id', 'status', 'created_at')
    list_filter = ('transaction_type', 'status', 'created_at')
    search_fields = ('user__username', 'reference_id', 'description')
    readonly_fields = ('created_at',)
    ordering = ('-created_at',)

@admin.register(Transaction)
class TransactionAdmin(admin.ModelAdmin):
    list_display = ('vle', 'service_type', 'customer_name', 'amount', 'commission', 'status', 'reference_number', 'date')
    list_filter = ('service_type', 'status', 'date')
    search_fields = ('vle__username', 'customer_name', 'reference_number')
    readonly_fields = ('date',)
    ordering = ('-date',)

@admin.register(VLEPerformance)
class VLEPerformanceAdmin(admin.ModelAdmin):
    list_display = ('vle', 'date', 'total_transactions', 'total_amount', 'commission_earned')
    list_filter = ('date',)
    search_fields = ('vle__username',)
    readonly_fields = ('date',)
    ordering = ('-date',) 