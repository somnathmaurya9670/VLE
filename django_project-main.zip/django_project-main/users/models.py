from django.db import models
from django.contrib.auth.models import AbstractUser
from decimal import Decimal

class User(AbstractUser):
    is_vle = models.BooleanField(default=False, help_text="Whether this user is a VLE")
    is_admin = models.BooleanField(default=False, help_text="Whether this user is an admin")
    phone_number = models.CharField(max_length=15, blank=True)
    address = models.TextField(blank=True)
    center_name = models.CharField(max_length=100, blank=True)
    center_code = models.CharField(max_length=50, blank=True)
    district = models.CharField(max_length=100, blank=True)
    state = models.CharField(max_length=100, blank=True)
    wallet_balance = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    kyc_verified = models.BooleanField(default=False)
    kyc_document = models.FileField(upload_to='kyc_documents/', null=True, blank=True)
    kyc_status = models.CharField(max_length=20, choices=[
        ('pending', 'Pending'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected')
    ], default='pending')

    def add_to_wallet(self, amount):
        if amount <= 0:
            raise ValueError("Amount must be greater than zero")
        self.wallet_balance += Decimal(str(amount))
        self.save()

    def deduct_from_wallet(self, amount):
        if amount <= 0:
            raise ValueError("Amount must be greater than zero")
        if self.wallet_balance < Decimal(str(amount)):
            raise ValueError("Insufficient wallet balance")
        self.wallet_balance -= Decimal(str(amount))
        self.save()

class WalletTransaction(models.Model):
    TRANSACTION_TYPES = [
        ('credit', 'Credit'),
        ('debit', 'Debit'),
        ('commission', 'Commission'),
        ('refund', 'Refund')
    ]

    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='wallet_transactions')
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    transaction_type = models.CharField(max_length=20, choices=TRANSACTION_TYPES)
    description = models.TextField()
    reference_id = models.CharField(max_length=100, unique=True)
    created_at = models.DateTimeField(auto_now_add=True)
    status = models.CharField(max_length=20, choices=[
        ('pending', 'Pending'),
        ('completed', 'Completed'),
        ('failed', 'Failed')
    ], default='pending')

    class Meta:
        ordering = ['-created_at']

class VLEPerformance(models.Model):
    vle = models.ForeignKey(User, on_delete=models.CASCADE, related_name='performance')
    date = models.DateField(auto_now_add=True)
    total_transactions = models.IntegerField(default=0)
    total_amount = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    commission_earned = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    services_provided = models.JSONField(default=dict)  # Store service-wise statistics

    class Meta:
        ordering = ['-date']
        unique_together = ('vle', 'date')

class Transaction(models.Model):
    vle = models.ForeignKey(User, on_delete=models.CASCADE, related_name='transactions')
    date = models.DateTimeField(auto_now_add=True)
    service_type = models.CharField(max_length=100)
    customer_name = models.CharField(max_length=100)
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    commission = models.DecimalField(max_digits=10, decimal_places=2)
    status = models.CharField(max_length=20, default='Completed')
    reference_number = models.CharField(max_length=100, blank=True)

    class Meta:
        ordering = ['-date'] 