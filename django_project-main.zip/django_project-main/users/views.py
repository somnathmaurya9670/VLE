from django.shortcuts import render, redirect
from django.contrib.auth import login, logout
from django.contrib.auth.decorators import login_required, user_passes_test
from django.contrib import messages
from .forms import UserRegistrationForm, UserLoginForm, AdminRegistrationForm, AdminLoginForm
from .models import User, VLEPerformance, Transaction
from django.db import models
from django.db.models import Sum, Count
from datetime import datetime, timedelta
import json

def home(request):
    return render(request, 'home.html')

def pm_kisan(request):
    return render(request, 'pm_kisan.html')

def ayushman_bharat(request):
    return render(request, 'ayushman_bharat.html')

def register(request):
    if request.method == 'POST':
        form = UserRegistrationForm(request.POST)
        if form.is_valid():
            user = form.save(commit=False)
            user.is_vle = True  # Default to VLE role
            user.save()
            login(request, user)
            messages.success(request, 'Registration successful!')
            return redirect('vle_dashboard')
    else:
        form = UserRegistrationForm()
    return render(request, 'users/register.html', {'form': form})

def admin_register(request):
    if request.method == 'POST':
        form = AdminRegistrationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            messages.success(request, 'Admin registration successful!')
            return redirect('admin_dashboard')
    else:
        form = AdminRegistrationForm()
    return render(request, 'users/custom_admin_register.html', {'form': form})

def user_login(request):
    if request.user.is_authenticated:
        if request.user.is_admin:
            return redirect('admin_dashboard')
        else:
            return redirect('vle_dashboard')
            
    if request.method == 'POST':
        form = UserLoginForm(data=request.POST)
        if form.is_valid():
            user = form.get_user()
            if user.is_admin:
                messages.error(request, 'Please use the admin login page to access admin features.')
                return redirect('admin_login')
            if not user.is_vle:
                messages.error(request, 'This login page is only for VLE users.')
                return redirect('vle_login')
            if not user.is_active:
                messages.error(request, 'Your account has been deactivated. Please contact the administrator.')
                return redirect('vle_login')
            login(request, user)
            messages.success(request, 'VLE login successful!')
            return redirect('vle_dashboard')
    else:
        form = UserLoginForm()
    return render(request, 'users/login.html', {'form': form})

def admin_login(request):
    if request.user.is_authenticated:
        if request.user.is_admin:
            return redirect('admin_dashboard')
        else:
            messages.error(request, 'Please use the VLE login page to access VLE features.')
            return redirect('vle_login')
            
    if request.method == 'POST':
        form = AdminLoginForm(data=request.POST)
        if form.is_valid():
            user = form.get_user()
            if not user.is_admin:
                messages.error(request, 'This login page is only for admin users.')
                return redirect('vle_login')
            login(request, user)
            messages.success(request, 'Admin login successful!')
            return redirect('admin_dashboard')
    else:
        form = AdminLoginForm()
    return render(request, 'users/admin_login.html', {'form': form})

@login_required
def user_logout(request):
    logout(request)
    return redirect('home')

@login_required
@user_passes_test(lambda u: u.is_vle)
def vle_dashboard(request):
    # Get the VLE's performance data
    performance = VLEPerformance.objects.filter(vle=request.user).first()
    
    # Calculate total statistics from all performance records
    total_stats = VLEPerformance.objects.filter(vle=request.user).aggregate(
        total_transactions=models.Sum('total_transactions'),
        total_amount=models.Sum('total_amount'),
        total_commission=models.Sum('commission_earned')
    )
    
    # Get recent individual transactions (last 10)
    recent_transactions = Transaction.objects.filter(
        vle=request.user
    ).order_by('-date')[:10]
    
    # Get categorized transaction counts
    categorized_transactions = Transaction.objects.filter(vle=request.user).values(
        'service_type'
    ).annotate(
        count=models.Count('id'),
        total_amount=models.Sum('amount'),
        total_commission=models.Sum('commission')
    ).order_by('-count')
    
    # Get performance data for the chart (last 7 days)
    end_date = datetime.now().date()
    start_date = end_date - timedelta(days=7)
    
    performance_data = VLEPerformance.objects.filter(
        vle=request.user,
        date__range=[start_date, end_date]
    ).order_by('date')
    
    # Get services count from the most recent performance record
    services_count = 0
    if performance and performance.services_provided:
        services_count = sum(stats.get('count', 0) for stats in performance.services_provided.values())
    
    # Prepare performance data for chart
    performance_dates = []
    performance_values = []
    for data in performance_data:
        performance_dates.append(data.date.strftime('%Y-%m-%d'))
        performance_values.append(data.total_transactions)
    
    context = {
        'performance': performance,
        'recent_transactions': recent_transactions,
        'categorized_transactions': categorized_transactions,
        'total_transactions': total_stats['total_transactions'] or 0,
        'total_amount': total_stats['total_amount'] or 0,
        'commission_earned': total_stats['total_commission'] or 0,
        'services_count': services_count,
        'performance_dates': performance_dates,
        'performance_data': performance_values,
    }
    
    return render(request, 'users/vle_dashboard.html', context)

@login_required
@user_passes_test(lambda u: u.is_admin)
def admin_dashboard(request):
    vles = User.objects.filter(is_vle=True)
    active_vles_count = vles.filter(is_active=True).count()
    total_transactions = VLEPerformance.objects.aggregate(total=models.Sum('total_transactions'))['total'] or 0
    total_amount = VLEPerformance.objects.aggregate(total=models.Sum('total_amount'))['total'] or 0
    
    # Get service-wise statistics
    service_stats = {}
    for vle_perf in VLEPerformance.objects.all():
        for service, count in vle_perf.services_provided.items():
            if service not in service_stats:
                service_stats[service] = {'count': 0, 'amount': 0}
            service_stats[service]['count'] += count.get('count', 0)
            service_stats[service]['amount'] += count.get('amount', 0)
    
    # Get recent transactions
    recent_transactions = VLEPerformance.objects.select_related('vle').order_by('-date')[:10]
    
    # Get district-wise VLE distribution
    district_stats = {}
    for vle in vles:
        district = vle.district
        if district:  # Check if district is not None
            if district not in district_stats:
                district_stats[district] = 0
            district_stats[district] += 1
    context = {
        'vles': vles,
        'active_vles_count': active_vles_count,
        'total_transactions': total_transactions,
        'total_amount': total_amount,
        'service_stats': service_stats,
        'recent_transactions': recent_transactions,
        'district_stats': district_stats,
    }
    return render(request, 'users/custom_admin_dashboard.html', context)

@login_required(login_url='admin_login')
@user_passes_test(lambda u: u.is_admin)
def vle_performance(request, vle_id):
    try:
        vle = User.objects.get(id=vle_id)
        performance = VLEPerformance.objects.filter(vle=vle).order_by('-date')
        
        # Calculate monthly statistics
        monthly_stats = {}
        for perf in performance:
            month_key = perf.date.strftime('%Y-%m')
            if month_key not in monthly_stats:
                monthly_stats[month_key] = {
                    'transactions': 0,
                    'amount': 0,
                    'commission': 0
                }
            monthly_stats[month_key]['transactions'] += perf.total_transactions
            monthly_stats[month_key]['amount'] += perf.total_amount
            monthly_stats[month_key]['commission'] += perf.commission_earned
        
        context = {
            'vle': vle,
            'performance': performance,
            'monthly_stats': monthly_stats
        }
        return render(request, 'users/vle_performance.html', context)
    except User.DoesNotExist:
        messages.error(request, 'VLE not found')
        return redirect('admin_dashboard')

@login_required
@user_passes_test(lambda u: u.is_admin)
def toggle_vle_status(request, vle_id):
    try:
        if request.method == 'POST':
            vle = User.objects.get(id=vle_id)
            vle.is_active = not vle.is_active
            vle.save()
            messages.success(request, f'VLE {vle.username} has been {"activated" if vle.is_active else "deactivated"}')
        return redirect('admin_dashboard')
    except User.DoesNotExist:
        messages.error(request, 'VLE not found')
        return redirect('admin_dashboard')

@login_required
@user_passes_test(lambda u: u.is_admin)
def edit_vle(request, vle_id):
    vle = User.objects.get(id=vle_id)
    if request.method == 'POST':
        vle.center_name = request.POST.get('center_name')
        vle.center_code = request.POST.get('center_code')
        vle.district = request.POST.get('district')
        vle.state = request.POST.get('state')
        vle.phone_number = request.POST.get('phone_number')
        vle.address = request.POST.get('address')
        vle.save()
        messages.success(request, f'VLE {vle.username} has been updated successfully')
        return redirect('admin_dashboard')
    return render(request, 'users/edit_vle.html', {'vle': vle})

@login_required
@user_passes_test(lambda u: u.is_vle)
def vle_transactions(request):
    # Get all transactions for the VLE
    transactions = Transaction.objects.filter(vle=request.user).order_by('-date')
    
    # Get categorized transaction counts
    categorized_transactions = Transaction.objects.filter(vle=request.user).values(
        'service_type'
    ).annotate(
        count=models.Count('id'),
        total_amount=models.Sum('amount'),
        total_commission=models.Sum('commission')
    ).order_by('-count')
    
    context = {
        'transactions': transactions,
        'categorized_transactions': categorized_transactions,
    }
    return render(request, 'users/vle_transactions.html', context)

@login_required
@user_passes_test(lambda u: u.is_vle)
def vle_performance(request):
    # Get the VLE's performance data
    performance = VLEPerformance.objects.filter(vle=request.user).order_by('-date')
    
    # Get performance data for the chart (last 30 days)
    end_date = datetime.now().date()
    start_date = end_date - timedelta(days=30)
    
    performance_data = VLEPerformance.objects.filter(
        vle=request.user,
        date__range=[start_date, end_date]
    ).order_by('date')
    
    # Prepare performance data for chart
    performance_dates = []
    performance_values = []
    for data in performance_data:
        performance_dates.append(data.date.strftime('%Y-%m-%d'))
        performance_values.append(data.total_transactions)
    
    context = {
        'performance': performance,
        'performance_dates': performance_dates,
        'performance_data': performance_values,
    }
    return render(request, 'users/vle_performance.html', context)

@login_required
@user_passes_test(lambda u: u.is_vle)
def vle_profile(request):
    if request.method == 'POST':
        user = request.user
        user.center_name = request.POST.get('center_name')
        user.center_code = request.POST.get('center_code')
        user.district = request.POST.get('district')
        user.state = request.POST.get('state')
        user.phone_number = request.POST.get('phone_number')
        user.address = request.POST.get('address')
        user.save()
        messages.success(request, 'Profile updated successfully!')
        return redirect('vle_profile')
    
    return render(request, 'users/vle_profile.html') 