from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('pm-kisan/', views.pm_kisan, name='pm_kisan'),
    path('ayushman-bharat/', views.ayushman_bharat, name='ayushman_bharat'),
    path('register/', views.register, name='register'),
    path('admin-portal/register/', views.admin_register, name='admin_register'),
    path('vle/login/', views.user_login, name='vle_login'),
    path('admin-portal/login/', views.admin_login, name='admin_login'),
    path('logout/', views.user_logout, name='logout'),
    path('vle/dashboard/', views.vle_dashboard, name='vle_dashboard'),
    path('vle/transactions/', views.vle_transactions, name='vle_transactions'),
    path('vle/performance/', views.vle_performance, name='vle_performance'),
    path('vle/profile/', views.vle_profile, name='vle_profile'),
    path('admin-portal/dashboard/', views.admin_dashboard, name='admin_dashboard'),
    path('admin-portal/vle/<int:vle_id>/toggle-status/', views.toggle_vle_status, name='toggle_vle_status'),
    path('admin-portal/vle/<int:vle_id>/edit/', views.edit_vle, name='edit_vle'),
] 